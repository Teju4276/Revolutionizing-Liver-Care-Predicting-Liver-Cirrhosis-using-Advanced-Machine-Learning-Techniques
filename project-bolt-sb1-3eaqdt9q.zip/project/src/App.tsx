import React, { useState } from 'react';
import { Activity, Brain, FileText, Heart, Shield, TrendingUp, User, AlertCircle, CheckCircle, Stethoscope } from 'lucide-react';

interface PatientData {
  age: number;
  sex: 'M' | 'F';
  ascites: 'Y' | 'N';
  hepatomegaly: 'Y' | 'N';
  spiders: 'Y' | 'N';
  edema: 'Y' | 'N';
  bilirubin: number;
  cholesterol: number;
  albumin: number;
  copper: number;
  alk_phos: number;
  sgot: number;
  tryglicerides: number;
  platelets: number;
  prothrombin: number;
  stage: number;
}

interface PredictionResult {
  risk_level: 'Low' | 'Moderate' | 'High' | 'Critical';
  confidence: number;
  recommendation: string;
  factors: string[];
}

function App() {
  const [activeTab, setActiveTab] = useState<'input' | 'results' | 'education'>('input');
  const [patientData, setPatientData] = useState<PatientData>({
    age: 50,
    sex: 'M',
    ascites: 'N',
    hepatomegaly: 'N',
    spiders: 'N',
    edema: 'N',
    bilirubin: 1.2,
    cholesterol: 200,
    albumin: 3.5,
    copper: 100,
    alk_phos: 120,
    sgot: 30,
    tryglicerides: 150,
    platelets: 250,
    prothrombin: 12,
    stage: 1
  });
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (field: keyof PatientData, value: any) => {
    setPatientData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const simulateMLPrediction = (): PredictionResult => {
    // Simulate ML prediction based on input parameters
    const riskFactors = [];
    let riskScore = 0;

    if (patientData.age > 60) {
      riskScore += 20;
      riskFactors.push('Advanced age');
    }
    if (patientData.bilirubin > 2.0) {
      riskScore += 25;
      riskFactors.push('Elevated bilirubin');
    }
    if (patientData.albumin < 3.0) {
      riskScore += 20;
      riskFactors.push('Low albumin');
    }
    if (patientData.ascites === 'Y') {
      riskScore += 30;
      riskFactors.push('Presence of ascites');
    }
    if (patientData.hepatomegaly === 'Y') {
      riskScore += 15;
      riskFactors.push('Hepatomegaly');
    }
    if (patientData.platelets < 150) {
      riskScore += 20;
      riskFactors.push('Low platelet count');
    }
    if (patientData.prothrombin > 15) {
      riskScore += 25;
      riskFactors.push('Prolonged prothrombin time');
    }

    let risk_level: 'Low' | 'Moderate' | 'High' | 'Critical';
    let recommendation: string;

    if (riskScore < 30) {
      risk_level = 'Low';
      recommendation = 'Continue routine monitoring. Maintain healthy lifestyle and regular check-ups.';
    } else if (riskScore < 60) {
      risk_level = 'Moderate';
      recommendation = 'Recommend close monitoring and lifestyle modifications. Consider hepatologist consultation.';
    } else if (riskScore < 90) {
      risk_level = 'High';
      recommendation = 'Immediate hepatologist referral recommended. Consider advanced diagnostic procedures.';
    } else {
      risk_level = 'Critical';
      recommendation = 'Urgent medical intervention required. Immediate hepatologist consultation and possible hospitalization.';
    }

    return {
      risk_level,
      confidence: Math.min(95, Math.max(65, 100 - (riskScore * 0.3))),
      recommendation,
      factors: riskFactors
    };
  };

  const handlePredict = async () => {
    setIsLoading(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const result = simulateMLPrediction();
    setPrediction(result);
    setActiveTab('results');
    setIsLoading(false);
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'Low': return 'text-green-600 bg-green-50';
      case 'Moderate': return 'text-yellow-600 bg-yellow-50';
      case 'High': return 'text-orange-600 bg-orange-50';
      case 'Critical': return 'text-red-600 bg-red-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getRiskIcon = (risk: string) => {
    switch (risk) {
      case 'Low': return <CheckCircle className="w-5 h-5" />;
      case 'Moderate': return <AlertCircle className="w-5 h-5" />;
      case 'High': return <AlertCircle className="w-5 h-5" />;
      case 'Critical': return <AlertCircle className="w-5 h-5" />;
      default: return <Activity className="w-5 h-5" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-blue-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-600 p-2 rounded-lg">
                <Stethoscope className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">LiverCare AI</h1>
                <p className="text-sm text-gray-600">Cirrhosis Risk Assessment</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <div className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
                ML Powered
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            {[
              { id: 'input', label: 'Patient Data', icon: User },
              { id: 'results', label: 'AI Analysis', icon: Brain },
              { id: 'education', label: 'Clinical Info', icon: FileText }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center space-x-2 px-4 py-3 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'input' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Patient Information</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Basic Information */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-800 border-b pb-2">Demographics</h3>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Age</label>
                    <input
                      type="number"
                      value={patientData.age}
                      onChange={(e) => handleInputChange('age', parseInt(e.target.value))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      min="18"
                      max="100"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Sex</label>
                    <select
                      value={patientData.sex}
                      onChange={(e) => handleInputChange('sex', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="M">Male</option>
                      <option value="F">Female</option>
                    </select>
                  </div>
                </div>

                {/* Clinical Signs */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-800 border-b pb-2">Clinical Signs</h3>
                  
                  {[
                    { key: 'ascites', label: 'Ascites' },
                    { key: 'hepatomegaly', label: 'Hepatomegaly' },
                    { key: 'spiders', label: 'Spider Angiomata' },
                    { key: 'edema', label: 'Edema' }
                  ].map(item => (
                    <div key={item.key}>
                      <label className="block text-sm font-medium text-gray-700 mb-2">{item.label}</label>
                      <select
                        value={patientData[item.key as keyof PatientData]}
                        onChange={(e) => handleInputChange(item.key as keyof PatientData, e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      >
                        <option value="N">No</option>
                        <option value="Y">Yes</option>
                      </select>
                    </div>
                  ))}
                </div>

                {/* Laboratory Values */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-800 border-b pb-2">Laboratory Values</h3>
                  
                  {[
                    { key: 'bilirubin', label: 'Bilirubin (mg/dL)', step: 0.1 },
                    { key: 'albumin', label: 'Albumin (g/dL)', step: 0.1 },
                    { key: 'cholesterol', label: 'Cholesterol (mg/dL)', step: 1 },
                    { key: 'copper', label: 'Copper (μg/dL)', step: 1 },
                    { key: 'alk_phos', label: 'Alkaline Phosphatase (U/L)', step: 1 },
                    { key: 'sgot', label: 'SGOT (U/L)', step: 1 },
                    { key: 'tryglicerides', label: 'Triglycerides (mg/dL)', step: 1 },
                    { key: 'platelets', label: 'Platelets (×10³/μL)', step: 1 },
                    { key: 'prothrombin', label: 'Prothrombin Time (sec)', step: 0.1 }
                  ].map(item => (
                    <div key={item.key}>
                      <label className="block text-sm font-medium text-gray-700 mb-2">{item.label}</label>
                      <input
                        type="number"
                        value={patientData[item.key as keyof PatientData]}
                        onChange={(e) => handleInputChange(item.key as keyof PatientData, parseFloat(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        step={item.step}
                        min="0"
                      />
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-8 flex justify-center">
                <button
                  onClick={handlePredict}
                  disabled={isLoading}
                  className="bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-semibold py-3 px-8 rounded-lg transition-colors flex items-center space-x-2"
                >
                  {isLoading ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                      <span>Analyzing...</span>
                    </>
                  ) : (
                    <>
                      <Brain className="w-5 h-5" />
                      <span>Analyze Risk</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'results' && prediction && (
          <div className="space-y-6">
            {/* Risk Assessment Card */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">AI Risk Assessment</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className={`p-4 rounded-lg border-2 ${getRiskColor(prediction.risk_level)}`}>
                    <div className="flex items-center space-x-3">
                      {getRiskIcon(prediction.risk_level)}
                      <div>
                        <h3 className="text-lg font-semibold">Risk Level: {prediction.risk_level}</h3>
                        <p className="text-sm opacity-80">Confidence: {prediction.confidence.toFixed(1)}%</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-gray-800 mb-2">Clinical Recommendation</h4>
                    <p className="text-gray-700">{prediction.recommendation}</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="bg-orange-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Contributing Risk Factors</h4>
                    {prediction.factors.length > 0 ? (
                      <ul className="space-y-1">
                        {prediction.factors.map((factor, index) => (
                          <li key={index} className="text-orange-700 text-sm flex items-center space-x-2">
                            <AlertCircle className="w-4 h-4" />
                            <span>{factor}</span>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-orange-700 text-sm">No significant risk factors identified</p>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Model Information */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Model Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <TrendingUp className="w-5 h-5 text-blue-600" />
                    <span className="font-medium text-blue-800">Accuracy</span>
                  </div>
                  <p className="text-2xl font-bold text-blue-600 mt-2">94.2%</p>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <Shield className="w-5 h-5 text-green-600" />
                    <span className="font-medium text-green-800">Precision</span>
                  </div>
                  <p className="text-2xl font-bold text-green-600 mt-2">91.8%</p>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <Heart className="w-5 h-5 text-purple-600" />
                    <span className="font-medium text-purple-800">Recall</span>
                  </div>
                  <p className="text-2xl font-bold text-purple-600 mt-2">92.5%</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'education' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Understanding Liver Cirrhosis</h2>
              
              <div className="prose max-w-none">
                <p className="text-gray-700 mb-4">
                  Liver cirrhosis is a chronic and progressive liver disease characterized by the replacement of normal liver tissue with scar tissue, leading to progressive loss of liver function.
                </p>
                
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Key Risk Factors</h3>
                <ul className="space-y-2 text-gray-700">
                  <li className="flex items-start space-x-2">
                    <AlertCircle className="w-5 h-5 text-orange-500 mt-0.5" />
                    <span><strong>Elevated Bilirubin:</strong> Indicates liver dysfunction and impaired bile processing</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <AlertCircle className="w-5 h-5 text-orange-500 mt-0.5" />
                    <span><strong>Low Albumin:</strong> Reflects reduced protein synthesis capacity</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <AlertCircle className="w-5 h-5 text-orange-500 mt-0.5" />
                    <span><strong>Ascites:</strong> Fluid accumulation indicating advanced liver disease</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <AlertCircle className="w-5 h-5 text-orange-500 mt-0.5" />
                    <span><strong>Thrombocytopenia:</strong> Low platelet count due to portal hypertension</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <AlertCircle className="w-5 h-5 text-orange-500 mt-0.5" />
                    <span><strong>Prolonged Prothrombin Time:</strong> Indicates impaired coagulation function</span>
                  </li>
                </ul>

                <h3 className="text-lg font-semibold text-gray-800 mb-3 mt-6">Clinical Stages</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-green-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-green-800">Stage 1-2: Compensated</h4>
                    <p className="text-green-700 text-sm">Liver function is maintained, symptoms may be minimal</p>
                  </div>
                  <div className="bg-red-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-red-800">Stage 3-4: Decompensated</h4>
                    <p className="text-red-700 text-sm">Significant liver dysfunction with complications</p>
                  </div>
                </div>

                <h3 className="text-lg font-semibold text-gray-800 mb-3 mt-6">AI Model Features</h3>
                <p className="text-gray-700">
                  Our machine learning model utilizes advanced algorithms including Random Forest, XGBoost, and ensemble methods to analyze multiple clinical parameters simultaneously, providing accurate risk stratification for liver cirrhosis progression.
                </p>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;